const createSpreadsheet = (rows, cols) => {
    const app = document.getElementById('app');
    const table = document.createElement('table');
    for (let i = 0; i < rows; i++) {
        const tr = document.createElement('tr');
        for (let j = 0; j < cols; j++) {
            const td = document.createElement('td');
            td.contentEditable = true; 
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    app.appendChild(table);

   
    table.addEventListener('click', (e) => {
        if (e.target.tagName === 'TD') {
            e.target.style.background = 'lightblue';
        }
    });

    table.addEventListener('dblclick', (e) => {
        if (e.target.tagName === 'TD') {
            e.target.style.background = '';
        }
    });
};

const applyBold = () => {
    document.execCommand('bold');
};

const applyItalic = () => {
    document.execCommand('italic');
};

const calculate = (operation) => {
    const cells = getSelectedCells();
    let result;
    switch (operation) {
        case 'SUM':
            result = cells.reduce((acc, cell) => acc + (parseFloat(cell.innerText) || 0), 0);
            break;
        case 'AVERAGE':
            result = cells.reduce((acc, cell) => acc + (parseFloat(cell.innerText) || 0), 0) / cells.length;
            break;
        case 'MAX':
            result = Math.max(...cells.map(cell => parseFloat(cell.innerText) || -Infinity));
            break;
        case 'MIN':
            result = Math.min(...cells.map(cell => parseFloat(cell.innerText) || Infinity));
            break;
        case 'COUNT':
            result = cells.filter(cell => !isNaN(cell.innerText) && cell.innerText.trim() !== '').length;
            break;
    }
    alert(`${operation}: ${result}`);
};

const trimCells = () => {
    const cells = getSelectedCells();
    cells.forEach(cell => {
        cell.innerText = cell.innerText.trim();
    });
};

const toUpper = () => {
    const cells = getSelectedCells();
    cells.forEach(cell => {
        cell.innerText = cell.innerText.toUpperCase();
    });
};

const toLower = () => {
    const cells = getSelectedCells();
    cells.forEach(cell => {
        cell.innerText = cell.innerText.toLowerCase();
    });
};

const removeDuplicates = () => {
    const cells = getSelectedCells();
    const uniqueValues = [...new Set(cells.map(cell => cell.innerText.trim()))];
    cells.forEach((cell, index) => {
        cell.innerText = uniqueValues[index] || '';
    });
};

const findAndReplace = () => {
    const findText = prompt("Enter text to find:");
    const replaceText = prompt("Enter text to replace with:");
    const cells = getSelectedCells();
    cells.forEach(cell => {
        cell.innerText = cell.innerText.replace(new RegExp(findText, 'g'), replaceText);
    });
};

const getSelectedCells = () => {
    const selectedCells = [];
    const table = document.querySelector('table');
    const selection = window.getSelection();
    const range = selection.getRangeAt(0);
    
    
    const startCell = range.startContainer.closest('td');
    const endCell = range.endContainer.closest('td');

    if (startCell && endCell) {
        const startRow = startCell.parentNode.rowIndex;
        const endRow = endCell.parentNode.rowIndex;

        const startCol = startCell.cellIndex;
        const endCol = endCell.cellIndex;

        
        for (let i = startRow; i <= endRow; i++) {
            const row = table.rows[i];
            for (let j = startCol; j <= endCol; j++) {
                selectedCells.push(row.cells[j]);
            }
        }
    }
    return selectedCells;
};


createSpreadsheet(20, 10); 