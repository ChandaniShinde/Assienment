const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Sample responses for demonstration
const responses = {
    "segment": {
        "setup source": "To set up a new source in Segment, go to the Sources tab and click on 'Add Source'.",
    },
    "mparticle": {
        "create user profile": "To create a user profile in mParticle, use the User API to create a new user.",
    },
    "lytics": {
        "build audience segment": "To build an audience segment in Lytics, navigate to the Audiences section.",
    },
    "zeotap": {
        "integrate data": "To integrate your data with Zeotap, follow the integration guide."
    }
};

// Endpoint to handle user queries
app.post('/ask', (req, res) => {
    const userQuestion = req.body.question.toLowerCase();
    let response = "I'm sorry, I can't help with that.";

    // Simple keyword matching for demonstration
    if (userQuestion.includes("set up a new source") && userQuestion.includes("segment")) {
        response = responses.segment["setup source"];
    } else if (userQuestion.includes("create a user profile") && userQuestion.includes("mparticle")) {
        response = responses.mparticle["create user profile"];
    } else if (userQuestion.includes("build an audience segment") && userQuestion.includes("lytics")) {
        response = responses.lytics["build audience segment"];
    } else if (userQuestion.includes("integrate my data") && userQuestion.includes("zeotap")) {
        response = responses.zeotap["integrate data"];
    }

    res.json({ answer: response });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});