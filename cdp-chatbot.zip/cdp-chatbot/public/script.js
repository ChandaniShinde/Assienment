document.getElementById('send-button').addEventListener('click', function() {
    const userInput = document.getElementById('user-input').value;
    const chatbox = document.getElementById('chatbox');

    // Display user question in chatbox
    chatbox.innerHTML += `<div>User: ${userInput}</div>`;
    document.getElementById('user-input').value = '';

    // Send user question to the server
    fetch('/ask', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: userInput })
    })
    .then(response => response.json())
    .then(data => {
        // Display bot response in chatbox
        chatbox.innerHTML += `<div>Bot: ${data.answer}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight; // Scroll to the bottom
    })
    .catch(error => {
        console.error('Error:', error);
    });
});